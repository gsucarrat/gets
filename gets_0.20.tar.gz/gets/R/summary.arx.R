summary.arx <-
function(object, ...)
{
  summary.default(object)
}
