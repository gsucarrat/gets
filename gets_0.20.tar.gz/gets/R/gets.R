gets <-
function(x, ...){ UseMethod("gets") }
