residuals.isat <-
function(object, std=FALSE, ...)
{
  residuals.arx(object, std=std, ...)
}
