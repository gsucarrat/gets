vcov.isat <-
function(object, ...)
{
  vcov.arx(object, ...)
}
