fitted.isat <-
function(object, spec=NULL, ...)
{
  fitted.arx(object, spec=spec)
  #OLD:
  #fitted.arx(object, spec="mean")
}
