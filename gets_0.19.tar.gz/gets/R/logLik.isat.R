logLik.isat <-
function(object, ...)
{
  logLik.arx(object)
}
