sigma.isat <-
function(object, ...)
{
  sigma.arx(object)
}
