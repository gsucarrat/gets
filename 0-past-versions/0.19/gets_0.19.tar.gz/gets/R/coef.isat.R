coef.isat <-
function(object, ...)
{
  coef.arx(object, spec="mean")
}
