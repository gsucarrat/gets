vcov.gets <-
function(object, spec=NULL,  ...)
{
  vcov.arx(object, spec=spec)
}
