summary.gets <-
function(object, ...)
{
  summary.default(object)
}
