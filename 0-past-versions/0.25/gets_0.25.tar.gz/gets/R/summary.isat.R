summary.isat <-
function(object, ...)
{
  summary.default(object)
}
