residuals.gets <-
function(object, std=NULL, ...)
{
  residuals.arx(object, std=std)
}
