toLatex.arx <-
function(object, ...)
{
  printtex(object, ...)
}
