sigma.gets <-
function(object, ...)
{
  sigma.arx(object)
}
