fitted.gets <-
function(object, spec=NULL, ...)
{
  fitted.arx(object, spec=spec)
}
