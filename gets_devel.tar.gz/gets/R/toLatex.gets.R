toLatex.gets <-
function(object, ...)
{
  printtex(object, ...)
}
