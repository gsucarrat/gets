logLik.gets <-
function(object, ...)
{
  logLik.arx(object)
}
