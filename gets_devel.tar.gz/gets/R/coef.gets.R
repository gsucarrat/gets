coef.gets <-
function(object, spec=NULL, ...)
{
  coef.arx(object, spec=spec)
}
